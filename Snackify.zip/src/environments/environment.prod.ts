export const environment = {
  production: true,
  apiUrl: 'https://restaurant-api.runasp.net/api',
  imageUrl: 'https://restaurant-api.runasp.net/images/',
  // Update with your production API base URL
};
