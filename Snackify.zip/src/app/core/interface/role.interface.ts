export interface Role {
  roleID: string;
  roleName: string;
}
