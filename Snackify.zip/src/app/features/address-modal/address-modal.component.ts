import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-address-modal',
  templateUrl: './address-modal.component.html',
  styleUrls: ['./address-modal.component.scss'],
})
export class AddressModalComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
